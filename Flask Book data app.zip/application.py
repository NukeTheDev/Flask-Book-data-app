from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# set the URI for the database to be used
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///books.db'

# initialize the database object
db = SQLAlchemy(app)

# define the Book model with the specified parameters
class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_name = db.Column(db.String(50), unique=True, nullable=False)
    publisher = db.Column(db.String(50), nullable=False)
    author = db.Column(db.String(50), nullable=False)

    # define the string representation of a Book object
    def __repr__(self):
        return f"{self.book_name} - {self.publisher} - {self.author}"

# route to get all books
@app.route('/books')
def get_books():
    books = Book.query.all()

    output=[]
    for book in books:
        book_data = {"book_name": book.book_name, "publisher": book.publisher, "author": book.author}

        output.append(book_data)

    return {"books": output}


# route to get a single book by ID
@app.route('/books/<id>')
def get_book(id):
    book = Book.query.get_or_404(id)
    # return the Book object details in JSON format
    return {"book_name": book.book_name, "publisher": book.publisher, "author": book.author}


# route to create a new book
@app.route('/books', methods=['POST'])
def add_book():
    # get the JSON data from the request body
    book = Book(book_name=request.json['book_name'], publisher=request.json['publisher'], 
                author=request.json['author'])
    # add the new Book object to the database
    db.session.add(book)
    db.session.commit()
    return {'id': book.id}

# route to delete an existing book by ID
@app.route('/books/<id>', methods=['DELETE'])
def delete_book(id):
    # get the existing Book object by ID
    book = Book.query.get(id)
    if book is None:
        return {"error": "book does not exist"}
    # delete the existing Book object from the database
    db.session.delete(book)
    db.session.commit()
    # return an empty response with 204 status code
    return {"message": "yeet!@"}
